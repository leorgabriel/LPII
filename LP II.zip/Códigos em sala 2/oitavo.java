import java.util.Date;

class Pessoa {
    private String cpf;
    private String nome;
    private String rg;
    private String email;
    private String endereco;

    // Construtor da classe Pessoa
    public Pessoa(String cpf, String nome, String rg, String email, String endereco) {
        this.cpf = cpf;
        this.nome = nome;
        this.rg = rg;
        this.email = email;
        this.endereco = endereco;
    }

    // Métodos getters para acessar os atributos
    public String getCpf() {
        return cpf;
    }

    public String getNome() {
        return nome;
    }

    public String getRg() {
        return rg;
    }

    public String getEmail() {
        return email;
    }

    public String getEndereco() {
        return endereco;
    }
}

class Cliente extends Pessoa {
    private String login;
    private Date dataPrimeiraCompra;

    // Construtor da classe Cliente
    public Cliente(String cpf, String nome, String rg, String email, String endereco, String login, Date dataPrimeiraCompra) {
        super(cpf, nome, rg, email, endereco);
        this.login = login;
        this.dataPrimeiraCompra = dataPrimeiraCompra;
    }

    // Métodos getters para acessar os atributos da classe Cliente
    public String getLogin() {
        return login;
    }

    public Date getDataPrimeiraCompra() {
        return dataPrimeiraCompra;
    }
}

class Funcionario extends Pessoa {
    private String nis;
    private Date dataNascimento;
    private String escolaridade;
    private double salario;
    private String cargo;
    private Date entradaEmpresa;
    private String contaBanco;

    // Construtor da classe Funcionario
    public Funcionario(String cpf, String nome, String rg, String email, String endereco,
                       String nis, Date dataNascimento, String escolaridade, double salario,
                       String cargo, Date entradaEmpresa, String contaBanco) {
        super(cpf, nome, rg, email, endereco);
        this.nis = nis;
        this.dataNascimento = dataNascimento;
        this.escolaridade = escolaridade;
        this.salario = salario;
        this.cargo = cargo;
        this.entradaEmpresa = entradaEmpresa;
        this.contaBanco = contaBanco;
    }

    // Métodos getters para acessar os atributos da classe Funcionario
    public String getNis() {
        return nis;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }

    public String getEscolaridade() {
        return escolaridade;
    }

    public double getSalario() {
        return salario;
    }

    public String getCargo() {
        return cargo;
    }

    public Date getEntradaEmpresa() {
        return entradaEmpresa;
    }

    public String getContaBanco() {
        return contaBanco;
    }
}

public class oitavo {
    public static void main(String[] args) {
        // Criar um objeto Cliente
        Cliente cliente = new Cliente("12345678901", "João", "98765432", "joao@example.com", "Rua A, 123",
                "joao123", new Date());

        // Criar um objeto Funcionario
        Funcionario funcionario = new Funcionario("98765432109", "Maria", "12345678", "maria@example.com",
                "Avenida B, 456", "12345", new Date(), "Superior Completo", 5000.0, "Gerente",
                new Date(), "12345-6");

        // Acessar os dados do Cliente e Funcionario
        System.out.println("Dados do Cliente:");
        System.out.println("CPF: " + cliente.getCpf());
        System.out.println("Nome: " + cliente.getNome());
        System.out.println("Login: " + cliente.getLogin());
        System.out.println("Email: " + cliente.getEmail());
        System.out.println("RG: " + cliente.getRg());
        System.out.println("Endereço: " + cliente.getEndereco());
        System.out.println("Data Primeira Compra: " + cliente.getDataPrimeiraCompra());

        System.out.println("\nDados do Funcionário:");
        System.out.println("CPF: " + funcionario.getCpf());
        System.out.println("Nome: " + funcionario.getNome());
        System.out.println("NIS: " + funcionario.getNis());
        System.out.println("Email: " + funcionario.getEmail());
        System.out.println("RG: " + funcionario.getRg());
        System.out.println("Endereço: " + funcionario.getEndereco());
        System.out.println("Escolaridade: " + funcionario.getEscolaridade());
        System.out.println("Salário: " + funcionario.getSalario());
        System.out.println("Cargo: " + funcionario.getCargo());
        System.out.println("Entrada na Empresa: " + funcionario.getEntradaEmpresa());
        System.out.println("Conta Bancária: " + funcionario.getContaBanco());
    }
}
