import java.util.Scanner;

class Funcionario {
    int numeroFuncionario;
    double horasTrabalhadas;
    double valorPorHora;

    public Funcionario(int numeroFuncionario, double horasTrabalhadas, double valorPorHora) {
        this.numeroFuncionario = numeroFuncionario;
        this.horasTrabalhadas = horasTrabalhadas;
        this.valorPorHora = valorPorHora;
    }

    // calcular salário
    public double calcularSalario() {
        return horasTrabalhadas * valorPorHora;
    }
}

public class quinto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Funcionario funcionario1, funcionario2;

        // recebe infos
        System.out.print("Número do funcionário: ");
        int numeroFuncionario1 = scanner.nextInt();
        System.out.print("Horas trabalhadas: ");
        double horasTrabalhadas1 = scanner.nextDouble();
        System.out.print("Valor da hora: ");
        double valorPorHora1 = scanner.nextDouble();

        funcionario1 = new Funcionario(numeroFuncionario1, horasTrabalhadas1, valorPorHora1);

        // recebe infos 2
        System.out.print("Número do funcionário: ");
        int numeroFuncionario2 = scanner.nextInt();
        System.out.print("Horas trabalhadas: ");
        double horasTrabalhadas2 = scanner.nextDouble();
        System.out.print("Valor da hora: ");
        double valorPorHora2 = scanner.nextDouble();

        funcionario2 = new Funcionario(numeroFuncionario2, horasTrabalhadas2, valorPorHora2);

        // mostra resultado
        System.out.printf("\nSalário do funcionário %d: R$ %.2f%n", funcionario1.numeroFuncionario, funcionario1.calcularSalario());
        System.out.printf("Salário do funcionário %d: R$ %.2f%n", funcionario2.numeroFuncionario, funcionario2.calcularSalario());

        scanner.close();
    }
}
