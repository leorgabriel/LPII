import java.util.Scanner;

public class segundo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("Qual a forma geométrica:");
        System.out.println("1 - Triângulo");
        System.out.println("2 - Círculo");
        System.out.println("3 - Trapézio");
        System.out.println("4 - Quadrado");
        System.out.println("5 - Retângulo");
        int opcao = scanner.nextInt();

        double area = 0.0;

        switch(opcao) {
            case 1:
                System.out.println("Digite o tamanho da base: ");
                double baseTriangulo = scanner.nextDouble();
                System.out.println("Digite a altura: ");
                double alturaTriangulo = scanner.nextDouble();
                area = (baseTriangulo*alturaTriangulo)/2;
                System.out.println("Área do triângulo: " + area);
            case 2:
                System.out.println("Digite o raio: ");
                double raioCirculo = scanner.nextDouble();                
                area = (raioCirculo*raioCirculo)*3.14;
                System.out.println("Área do circulo: " + area);
            case 3:
                System.out.println("Digite o tamanho da base menor: ");
                double baseMenor = scanner.nextDouble();
                System.out.println("Digite o tamanho da base maior: ");
                double baseMaior = scanner.nextDouble();
                System.out.println("Digite a altura: ");
                double alturaTrapezio = scanner.nextDouble();
                area = ((baseMaior+baseMenor)*alturaTrapezio)/2;
                System.out.println("Área do triângulo: " + area);
            case 4:
                System.out.println("Digite o tamanho do lado: ");
                double ladoQuad = scanner.nextDouble();
                area = ladoQuad*ladoQuad;
                System.out.println("Área do quadrado: " + area);
            case 5:
                System.out.println("Digite o tamanho da base: ");
                double baseRet = scanner.nextDouble();
                System.out.println("Digite a altura: ");
                double alturaRet = scanner.nextDouble();
                area = baseRet*alturaRet;
                System.out.println("Área do retângulo: " + area);
        }
        
        scanner.close();
    }
}
