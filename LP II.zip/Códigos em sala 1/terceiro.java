import java.util.Scanner;

public class terceiro {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // inserção dados funcionário 1        
        System.out.print("Número do funcionário: ");
        int numeroFuncionario1 = scanner.nextInt();
        System.out.print("Horas trabalhadas: ");
        double horasTrabalhadas1 = scanner.nextDouble();
        System.out.print("Valor da hora: ");
        double valorPorHora1 = scanner.nextDouble();

        // calcula o primeiro salário
        double salario1 = horasTrabalhadas1 * valorPorHora1;

        // inserção dados funcionário 2       
        System.out.print("Número do funcionário: ");
        int numeroFuncionario2 = scanner.nextInt();
        System.out.print("Horas trabalhadas: ");
        double horasTrabalhadas2 = scanner.nextDouble();
        System.out.print("Valor da hora: ");
        double valorPorHora2 = scanner.nextDouble();

        // calcula o segundo salário
        double salario2 = horasTrabalhadas2 * valorPorHora2;

        // mostra os salários
        System.out.printf("\nSalário do funcionário %d: R$ %.2f%n", numeroFuncionario1, salario1);
        System.out.printf("Salário do funcionário %d: R$ %.2f%n", numeroFuncionario2, salario2);

        scanner.close();
    }
}
