import java.util.Scanner;

public class quarto {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // definindo vetor
        int numFuncionarios = 2; // Número de funcionários
        int[] numeros = new int[numFuncionarios];
        double[] horasTrabalhadas = new double[numFuncionarios];
        double[] valorPorHora = new double[numFuncionarios];
        double[] salarios = new double[numFuncionarios];

        // leitura dos funcionários
        for (int i = 0; i < numFuncionarios; i++) {            
            System.out.print("Número do funcionário: ");
            numeros[i] = scanner.nextInt();
            System.out.print("Horas trabalhadas: ");
            horasTrabalhadas[i] = scanner.nextDouble();
            System.out.print("Valor da hora: ");
            valorPorHora[i] = scanner.nextDouble();

            // calcula o salário
            salarios[i] = horasTrabalhadas[i] * valorPorHora[i];
        }

        // mostra resultado
        for (int i = 0; i < numFuncionarios; i++) {
            System.out.printf("Salário do funcionário %d: R$ %.2f%n", numeros[i], salarios[i]);
        }

        scanner.close();
    }
}
